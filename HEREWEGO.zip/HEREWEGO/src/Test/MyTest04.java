package Test;

import static org.junit.Assert.*;
import java.sql.Connection;
import java.sql.DriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.herewego.dao.UserDao;
import com.herewego.model.User;

public class MyTest04 {
	
	private Connection con ;
	private String dbUrl = "jdbc:mysql://localhost:3306/herewego" ; 
	private String dbUserName = "root" ;	
	private String dbPassword = "987654321+." ;
	private String jdbcName = "com.mysql.jdbc.Driver" ;
	private UserDao userDao = new UserDao();
	private User user = new User() ;
	private User targetUser = new User() ;
	private boolean b ;

	@Before
	public void setUp() throws Exception {	
		Class.forName(jdbcName) ;	
		con = DriverManager.getConnection(dbUrl, dbUserName, dbPassword) ;
	}

	@After
	public void tearDown() throws Exception {		
		con = null ;
	}

	@Test
	public void testAddFriends() throws Exception {
		
		//好友表存在该记录
		user.setUserName("zcz");
		targetUser.setUserName("11111");		
		b = userDao.addFriend(con, user, targetUser) ;
		assertFalse(b);
		
		//好友表不存在该记录
		user.setUserName("zcz");
		targetUser.setUserName("yhx");		
		b = userDao.addFriend(con, user, targetUser) ;
		assertTrue(b);

	}
}
