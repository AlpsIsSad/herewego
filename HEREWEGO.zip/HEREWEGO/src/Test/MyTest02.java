package Test;

import static org.junit.Assert.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.herewego.dao.GoodDao;
import com.herewego.model.Good;

public class MyTest02 {
	
	private Connection con ;
	private String dbUrl = "jdbc:mysql://localhost:3306/herewego" ; 
	private String dbUserName = "root" ;	
	private String dbPassword = "987654321+." ;
	private String jdbcName = "com.mysql.jdbc.Driver" ;
	private GoodDao goodDao = new GoodDao();
	private Good good ;
	private ArrayList<Good> arr ;

	@Before
	public void setUp() throws Exception {	
		Class.forName(jdbcName) ;	
		con = DriverManager.getConnection(dbUrl, dbUserName, dbPassword) ;
	}

	@After
	public void tearDown() throws Exception {		
		con = null ;
	}

	@Test
	public void testGetGood() throws Exception {
		
		arr = goodDao.getGood(con) ;
		good = arr.get(0) ;
		
		assertEquals(2, good.getGood_id());
		assertEquals("剑", good.getName());
		assertEquals(1, good.getNumber());
		assertEquals("无", good.getContent() );
		
	}
}
