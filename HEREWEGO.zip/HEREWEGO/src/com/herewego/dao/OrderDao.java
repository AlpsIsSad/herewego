package com.herewego.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.herewego.model.Game;
import com.herewego.model.Good;
import com.herewego.model.Order;
import com.herewego.model.User;
import com.mysql.jdbc.PreparedStatement;

public class OrderDao {

	// 上架
	public boolean addOrder(Connection con, Good good, User user) throws Exception {

		String sql = " insert into myOrder values(?,?,?,?,?,?,?,?,?) ";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setInt(1, good.getGood_id());

		pstmt.setInt(2, good.getGood_id());

		pstmt.setString(3, good.getName());

		pstmt.setInt(4, good.getNumber());

		pstmt.setString(5, "");

		pstmt.setString(6, user.getUserName());

		pstmt.setFloat(7, good.getPrice());

		pstmt.setString(8, "7天");

		pstmt.setString(9, "出售中");

		pstmt.execute();

		return true;

	}
	
	// 购买商品生成订单
	public boolean buyOrder(Connection con, Good good, User user) throws Exception {

		String s1 = "select * from good where good_id = ? ";

		PreparedStatement p = (PreparedStatement) con.prepareStatement(s1);

		p.setInt(1, good.getGood_id());

		ResultSet rs = p.executeQuery();

		if (rs.next()) {

			String sql = " UPDATE myOrder SET buy_id = ? , state = ? where good_id = ?  ";

			PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

			pstmt.setString(1, user.getUserName());

			pstmt.setString(2, "已出售");

			pstmt.setInt(3, good.getGood_id());

			pstmt.execute();

			String sql2 = "delete from good where good_id = ? ";

			PreparedStatement pstmt2 = (PreparedStatement) con.prepareStatement(sql2);

			pstmt2.setInt(1, good.getGood_id());

			pstmt2.execute();

			return true;

		}

		else

			return false;
	}

	// 获取用户购买过的订单列表
	public ArrayList<Order> getBuyOrder(Connection con, User user) throws Exception {

		String sql = "select * from myorder where buy_id = ?";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setString(1, user.getUserName());

		ResultSet rs = pstmt.executeQuery();

		ArrayList<Order> str = new ArrayList<Order>();

		int i = 0;

		while (rs.next() && i <= 10) {

			Order order = new Order();

			order.setOrder_id(rs.getInt("order_id"));

			order.setGood_id(rs.getInt("good_id"));

			order.setName(rs.getString("name"));

			order.setNumber(rs.getInt("num"));

			order.setBuy_id(rs.getString("buy_id"));

			order.setSell_id(rs.getString("sell_id"));

			order.setPrice(rs.getInt("price"));

			order.setTime(rs.getString("time"));

			order.setState(rs.getString("state"));

			str.add(order);

			i++;

		}

		return str;

	}

	// 获取用户出售中的订单列表
	public ArrayList<Order> getSellOrder(Connection con, User user) throws Exception {

		String sql = "select * from myorder where sell_id = ? and state = '出售中'";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setString(1, user.getUserName());

		ResultSet rs = pstmt.executeQuery();

		ArrayList<Order> str = new ArrayList<Order>();

		int i = 0;

		while (rs.next() && i <= 10) {

			Order order = new Order();

			order.setOrder_id(rs.getInt("order_id"));

			order.setGood_id(rs.getInt("good_id"));

			order.setName(rs.getString("name"));

			order.setNumber(rs.getInt("num"));

			order.setBuy_id(rs.getString("buy_id"));

			order.setSell_id(rs.getString("sell_id"));

			order.setPrice(rs.getInt("price"));

			order.setTime(rs.getString("time"));

			order.setState(rs.getString("state"));

			str.add(order);

			i++;

		}

		return str;

	}

	// 获取用户出售中的订单列表
	public ArrayList<Order> getSoldOrder(Connection con, User user) throws Exception {

		String sql = "select * from myorder where sell_id = ? and state = '已出售'";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setString(1, user.getUserName());

		ResultSet rs = pstmt.executeQuery();

		ArrayList<Order> str = new ArrayList<Order>();

		int i = 0;

		while (rs.next() && i <= 10) {

			Order order = new Order();

			order.setOrder_id(rs.getInt("order_id"));

			order.setGood_id(rs.getInt("good_id"));

			order.setName(rs.getString("name"));

			order.setNumber(rs.getInt("num"));

			order.setBuy_id(rs.getString("buy_id"));

			order.setSell_id(rs.getString("sell_id"));

			order.setPrice(rs.getInt("price"));

			order.setTime(rs.getString("time"));

			order.setState(rs.getString("state"));

			str.add(order);

			i++;

		}

		return str;

	}

	// 获取订单信息
	public Order getOrderInfo(Connection con, Order order) throws Exception {

		String sql = "select * from myorder where order_id = ?";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setInt(1, order.getOrder_id());

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			order.setOrder_id(rs.getInt("order_id"));

			order.setGood_id(rs.getInt("good_id"));

			order.setName(rs.getString("name"));

			order.setNumber(rs.getInt("num"));

			order.setBuy_id(rs.getString("buy_id"));

			order.setSell_id(rs.getString("sell_id"));

			order.setPrice(rs.getInt("price"));

			order.setTime(rs.getString("time"));

			order.setState(rs.getString("state"));

		}

		return order;

	}
	
	
	//删除订单
		public boolean deleteOrder( Connection con , Order order) throws Exception {
			
			//查询该用户是否有该订单

			String sql = "select * from myorder where order_id = ? ";
			
			PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
			
			pstmt.setInt(1, order.getOrder_id());
			
			ResultSet rs = pstmt.executeQuery() ;
			
			//存在则删除
			if (rs.next()) {
				
				String deletesql = " delete from myorder where order_id = ? "  ;
				
				PreparedStatement registerpstmt = (PreparedStatement) con.prepareStatement(deletesql) ;
				
				registerpstmt.setInt(1, order.getOrder_id());
			
				registerpstmt.execute() ;
										
				return true ;
				
			}
			else
				
				return false ;
		}
}
