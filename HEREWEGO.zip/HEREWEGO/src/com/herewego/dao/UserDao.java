package com.herewego.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;
import com.herewego.model.Game;
import com.herewego.model.User;

public class UserDao {
	
	//登录功能
	
	public User login ( Connection con , User user ) throws Exception {
		
		User resultUser = null ;
		
		//查询是否存在对应的用户，密码
		String sql = "select * from user where user_id = ? and user_password = ? " ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());
		
		pstmt.setString(2, user.getPassword());
		
		ResultSet rs = pstmt.executeQuery() ;
		
		//从user_information获取该用户的信息
		String sql2 = "select * from user_information where user_id = ? " ;
		
		PreparedStatement pstmt2 = (PreparedStatement) con.prepareStatement(sql2) ;
		
		pstmt2.setString(1, user.getUserName()) ;
		
		ResultSet rs2 = pstmt2.executeQuery() ;
		
		if (rs.next()) {
			
			resultUser = new User() ;
			
			resultUser.setUserName(rs.getString("user_id"));
			
			resultUser.setPassword(rs.getString("user_password"));
			
			if (rs2.next()) {
			
			resultUser.setNickName(rs2.getString("user_name"));
			
			resultUser.setSex(rs2.getString("user_sex"));
			
			//获取得到的字符串转化为数值
			resultUser.setAge(Integer.parseInt(rs2.getString("user_age")));
			
			resultUser.setConstellation(rs2.getString("user_constellation"));
			
			}
			
		}
		
		//如果输入用户名，密码一项为空则返回null
		if (user.getUserName() == "" ) {
			
			resultUser = null ;
			
		}
		
		if (user.getPassword() == "" ) {
			
			resultUser = null ;
			
		}
		
		return resultUser ;
		
	}
	
	
	
	
	//注册功能
	public boolean register( Connection con , User user , Game game) throws Exception {
		
		//查询是否存在该用户	
		String sql = "select * from user where user_id = ? " ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());
				
		ResultSet rs = pstmt.executeQuery() ;
		
		//如果不存在
		if (!rs.next()) {
			
			//插入用户名，密码到user表
			String insertsql = " insert into user values(?,?) " ;
			
			PreparedStatement registerpstmt = (PreparedStatement) con.prepareStatement(insertsql) ;
			
			registerpstmt.setString(1, user.getUserName());
			
			registerpstmt.setString(2, user.getPassword());
			
			registerpstmt.execute() ;
			
			//插入用户信息到user_information表
			String insertsql2 = " insert into user_information values(?,?,?,?,?) " ;
			
			PreparedStatement registerpstmt2 = (PreparedStatement) con.prepareStatement(insertsql2) ;
			
			registerpstmt2.setString(1, user.getUserName());
			
			registerpstmt2.setString(2, user.getNickName());
			
			registerpstmt2.setString(3, user.getSex());
						
			registerpstmt2.setInt(4, user.getAge());
			
			registerpstmt2.setString(5, user.getConstellation());
			
			registerpstmt2.execute() ;
			
			//插入用户游戏，大区到user_game表
			String insertsql3 = " insert into user_game values(?,?,?) " ;
			
			PreparedStatement registerpstmt3 = (PreparedStatement) con.prepareStatement(insertsql3) ;
			
			registerpstmt3.setString(1, user.getUserName());
			
			registerpstmt3.setString(2, game.getGameName());
			
			registerpstmt3.setString(3, game.getGameDistrict());
			
			registerpstmt3.execute() ;
						
			return true ;
					
		}
		else
			
			//如果存在该用户，返回false
			return false ;
	
	}
	
	//获取用户游戏
	public ArrayList<Game> getGame( Connection con , User user ) throws Exception {
		
		//查询该用户的游戏
		String sql = "select * from user_game where user_id = ? " ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());
		
		ResultSet rs = pstmt.executeQuery() ;
		
		ArrayList<Game> str = new ArrayList<Game>()  ;
		
		//存在，返回用户游戏，大区对象
		while ( rs.next() ) {
			
			Game game = new Game() ;
			
			game.setGameName(rs.getString("user_game"));
			
			game.setGameDistrict(rs.getString("user_district"));
			
			str.add(game)  ;
			
		}
		
		return str ;

	}
	
	//添加游戏
	public boolean addGame( Connection con , User user , Game game) throws Exception {
		
		//查询该用户是否已经有该游戏
		String sql = "select * from user_game where user_id = ?  and user_game = ? and user_district = ?" ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());
		
		pstmt.setString(2, game.getGameName());
		
		pstmt.setString(3, game.getGameDistrict());
		
		ResultSet rs = pstmt.executeQuery() ;
		
		//不存在则添加
		if (!rs.next()) {
			
			String insertsql = " insert into user_game values(?,?,?) " ;
			
			PreparedStatement registerpstmt = (PreparedStatement) con.prepareStatement(insertsql) ;
			
			registerpstmt.setString(1, user.getUserName());
			
			registerpstmt.setString(2, game.getGameName());
			
			registerpstmt.setString(3, game.getGameDistrict());
			
			registerpstmt.execute() ;
									
			return true ;
			
		}
		else
			
			return false ;
	}
	
	
	
	//删除游戏
	public boolean deleteGame( Connection con , User user , Game game) throws Exception {
		
		//查询该用户是否有该游戏
		String sql = "select * from user_game where user_id = ?  and user_game = ? and user_district = ?" ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());
		
		pstmt.setString(2, game.getGameName());
		
		pstmt.setString(3, game.getGameDistrict());
		
		ResultSet rs = pstmt.executeQuery() ;
		
		//存在则删除
		if (rs.next()) {
			
			String deletesql = " delete from user_game where user_id = ?  and user_game = ? and user_district = ?"  ;
			
			PreparedStatement registerpstmt = (PreparedStatement) con.prepareStatement(deletesql) ;
			
			registerpstmt.setString(1, user.getUserName());
			
			registerpstmt.setString(2, game.getGameName());
			
			registerpstmt.setString(3, game.getGameDistrict());
			
			registerpstmt.execute() ;
									
			return true ;
			
		}
		else
			
			return false ;
	}
	
	//获取用户信息
		public User getUser( Connection con , User user ) throws Exception {
			
			//查询该用户的信息
			String sql = "select * from user_information where user_id = ? " ;
			
			PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
			
			pstmt.setString(1, user.getUserName());
			
			ResultSet rs = pstmt.executeQuery() ;
			
			User newUser = new User() ;
			
			//存在，返回用户信息
			while ( rs.next() ) {
	
				newUser.setUserName(rs.getString("user_id"));
				
				newUser.setNickName(rs.getString("user_name"));
				
				newUser.setSex(rs.getString("user_sex"));
				
				newUser.setAge(Integer.parseInt(rs.getString("user_age")));
				
				newUser.setConstellation(rs.getString("user_constellation"));				
			}
			
			return newUser ;

		}
	
	
	//修改用户信息
	public boolean alterInfo(Connection con, User user) throws Exception {
		
		//更新用户信息
		String sql = "update user_information set user_name = ? , "
				+ "user_sex = ? , " 
				+ "user_age = ? , "
				+ "user_constellation = ? where user_id = ? "  ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getNickName());
		
		pstmt.setString(2, user.getSex());
		
		pstmt.setInt(3, user.getAge());
		
		pstmt.setString(4, user.getConstellation());
		
		pstmt.setString(5, user.getUserName());
		
		pstmt.execute() ;
		
		return true ;


	}
	
	
	
	
	//添加好友
	public boolean addFriend ( Connection con , User user , User targetUser ) throws Exception {
			
		String sql = "select * from user_friends where user_id = ? and user_friend = ? " ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());
		
		pstmt.setString(2, targetUser.getUserName());
		
		ResultSet rs = pstmt.executeQuery() ;
		
		if (!rs.next()) {
			
		String insertsql = " insert into user_friends values(?,?) " ;
			
			PreparedStatement registerpstmt = (PreparedStatement) con.prepareStatement(insertsql) ;
			
			registerpstmt.setString(1, user.getUserName());
			
			registerpstmt.setString(2, targetUser.getUserName());
			
			registerpstmt.execute() ;
									
			return true ;
					
		}
		else
			
			return false ;
	}
	
	
	
	//删除好友
	public boolean deleteFriend ( Connection con , User user , User targetUser ) throws Exception {
		
		String sql = "select * from user_friends where user_id = ? and user_friend = ? " ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());
		
		pstmt.setString(2, targetUser.getUserName());
		
		ResultSet rs = pstmt.executeQuery() ;
		
		if ( rs.next()) {
			
		String deletesql = " delete from user_friends where user_id = ? and user_friend = ? " ;
			
			PreparedStatement deletepstmt = (PreparedStatement) con.prepareStatement(deletesql) ;
			
			deletepstmt.setString(1, user.getUserName());
			
			deletepstmt.setString(2, targetUser.getUserName());
			
			deletepstmt.execute() ;
									
			return true ;
					
		}
		else
			
			return false ;
	}

	//获取我的好友
	public ArrayList<String> getFriends(Connection con, User user) throws Exception {
		
		String sql = "select * from user_friends where user_id = ? "  ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());

		ResultSet rs = pstmt.executeQuery() ;
		
		ArrayList<String> str = new ArrayList<String>()  ;
				
		while ( rs.next() ) {
			
			str.add(rs.getString("user_friend"))  ;
			
		}
		
		return str ;

	}
	
	//获取推荐好友
	public ArrayList<String> getRecFriends(Connection con, User user) throws Exception {
		
		String sql = "select * from user_game where user_id = ? "  ;
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql) ;
		
		pstmt.setString(1, user.getUserName());

		ResultSet rs = pstmt.executeQuery() ;
		
		if ( rs.next() ) {
			
			Game game = new Game() ;
			
			game.setGameName(rs.getString("user_game"));
			
			game.setGameDistrict(rs.getString("user_district"));
			
			String sql2 = "select * from user_game where user_game = ? and user_district = ? "  ;
			
			PreparedStatement pstmt2 = (PreparedStatement) con.prepareStatement(sql2) ;
			
			pstmt2.setString(1, game.getGameName());
			
			pstmt2.setString(2, game.getGameDistrict());

			ResultSet rs2 = pstmt2.executeQuery() ;
			
			ArrayList<String> str = new ArrayList<String>()  ;
			
			int i = 0 ;
			
				while ( rs2.next() && i <= 5 ) {
				
					str.add(rs2.getString("user_id"))  ;
					
					i ++ ; 
				
				} 
				
				str.remove(user.getUserName()) ;
				
				return str ;
		
		} else {
			
			return null ;
			
		}	
	}	
	
}
