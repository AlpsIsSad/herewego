package com.herewego.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.herewego.model.Good;
import com.herewego.model.User;
import com.mysql.jdbc.PreparedStatement;

public class GoodDao {

	OrderDao orderDao = new OrderDao();

	// 上架
	public boolean addGood(Connection con, Good good, User user) throws Exception {

		String sql = " insert into good values(?,?,?,?,?,?,?) ";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setInt(1, good.getGood_id());

		pstmt.setString(2, good.getName());

		pstmt.setInt(3, good.getNumber());

		pstmt.setFloat(4, good.getPrice());

		pstmt.setString(5, good.getContent());

		pstmt.setTimestamp(6, new Timestamp(System.currentTimeMillis()));

		pstmt.setTimestamp(7, (new Timestamp(System.currentTimeMillis())));

		pstmt.execute();

		orderDao.addOrder(con, good, user);

		return true;

	}

	// 获取商品列表
	public ArrayList<Good> getGood(Connection con) throws Exception {

		String sql = "select * from good order by addtime desc";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		ResultSet rs = pstmt.executeQuery();

		ArrayList<Good> str = new ArrayList<Good>();

		int i = 0;

		while (rs.next() && i <= 10) {

			Good good = new Good();

			good.setGood_id(rs.getInt("good_id"));

			good.setName(rs.getString("name"));

			good.setNumber(rs.getInt("num"));

			good.setPrice(rs.getInt("price"));

			good.setContent(rs.getString("content"));

			good.setAddTime(rs.getString("addtime"));

			good.setEndTime(rs.getString("endtime"));

			str.add(good);

			i++;

		}

		return str;

	}

	// 获取商品信息
	public Good getGoodInfo(Connection con, Good good) throws Exception {

		String sql = "select * from good where good_id = ?";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setInt(1, good.getGood_id());

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {

			good.setGood_id(rs.getInt("good_id"));

			good.setName(rs.getString("name"));

			good.setNumber(rs.getInt("num"));

			good.setPrice(rs.getInt("price"));

			good.setContent(rs.getString("content"));

			good.setAddTime(rs.getString("addtime"));

			good.setEndTime(rs.getString("endtime"));

		}

		return good;

	}
}
