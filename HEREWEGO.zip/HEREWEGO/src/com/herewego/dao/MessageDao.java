package com.herewego.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.herewego.model.Message;
import com.herewego.model.User;

public class MessageDao {

	// 发送消息
	public boolean sendMessage(Connection con, Message message) throws Exception {

		String sql = " insert into user_message values(?,?,?,?) ";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setString(1, message.getUserName());

		pstmt.setString(2, message.getToUserName());

		pstmt.setString(3, message.getMessage());

		pstmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

		pstmt.execute();

		return true;

	}

	// 获取私有消息
	public ArrayList<Message> getOwnMessage(Connection con, User user) throws Exception {

		String sql = "select * from user_message where touser = ?  order by user_add_time desc";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setString(1, user.getUserName());

		ResultSet rs = pstmt.executeQuery();

		ArrayList<Message> str = new ArrayList<Message>();

		int i = 0;

		while (rs.next() && i <= 10) {

			Message message = new Message();

			message.setUserName(rs.getString("user_id"));

			message.setToUserName(rs.getString("touser"));

			message.setMessage(rs.getString("user_message"));

			message.setDatetime(rs.getString("user_add_time"));

			str.add(message);

			i++;

		}

		return str;

	}

	public boolean sendAllMessage(Connection con, Message message) throws Exception {

		String sql = " insert into user_message values(?,?,?,?) ";

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(sql);

		pstmt.setString(1, message.getUserName());

		pstmt.setString(2, "all");

		pstmt.setString(3, message.getMessage());

		pstmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

		pstmt.execute();

		return true;

	}

	public ArrayList<Message> getAllMessage(Connection con, User user) throws Exception {

		String sql = "select * from user_message where touser = 'all' order by user_add_time desc";

		Statement st = (Statement) con.createStatement();

		ResultSet rs = st.executeQuery(sql);

		ArrayList<Message> str = new ArrayList<Message>();

		int i = 0;

		while (rs.next() && i <= 10) {

			Message message = new Message();

			message.setUserName(rs.getString("user_id"));

			message.setToUserName(rs.getString("touser"));

			message.setMessage(rs.getString("user_message"));

			message.setDatetime(rs.getString("user_add_time"));

			str.add(message);

			i++;

		}

		return str;

	}

}
