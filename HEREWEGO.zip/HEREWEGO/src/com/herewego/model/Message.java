package com.herewego.model;

public class Message {
	
	String userName ;
	
	String toUserName ;
	
	String message ;
	
	String datetime ;
	
	public Message() {
		
		super();
				
	}
	
	



	public Message(String userName, String message) {
		
		super();
		
		this.userName = userName;
		
		this.message = message;
		
	}





	public Message(String userName, String toUserName, String message) {
		
		super();
		
		this.userName = userName;
		
		this.toUserName = toUserName;
		
		this.message = message;
		
	}
	
	

	public Message(String userName, String toUserName, String message, String datetime) {
		
		super();
		
		this.userName = userName;
		
		this.toUserName = toUserName;
		
		this.message = message;
		
		this.datetime = datetime;
	}

	public String getUserName() {
		
		return userName;
		
	}

	public void setUserName(String userName) {
		
		this.userName = userName;
		
	}

	public String getToUserName() {
		
		return toUserName;
		
	}

	public void setToUserName(String toUserName) {
		
		this.toUserName = toUserName;
		
	}

	public String getMessage() {
		
		return message;
		
	}

	public void setMessage(String message) {
		
		this.message = message;
		
	}

	public String getDatetime() {
		
		return datetime;
		
	}

	public void setDatetime(String datetime) {
		
		this.datetime = datetime;
		
	}

	
	
	
	
	

}
