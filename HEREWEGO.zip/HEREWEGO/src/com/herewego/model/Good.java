package com.herewego.model;


public class Good {
	
	public static int id = 1 ;
	
	private int good_id ;
	
	private String name ;
	
	private int number ;
	
	private float price ;
	
	private String content ;
	
	private String addTime ;
	
	private String endTime ;
	
	
	


	public int getGood_id() {
		return good_id;

	}

	public void setGood_id(int good_id) {
		this.good_id = good_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getAddTime() {
		return addTime;
	}

	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public Good() {}

	public Good(String name, int number, float price, String content, String addTime, String endTime) {
		this.good_id = id;
		this.name = name;
		this.number = number;
		this.price = price;
		this.content = content;
		this.addTime = addTime;
		this.endTime = endTime;
		id++ ;
	}

	public Good(String name, int number, float price, String content) {

		this.good_id = id;
		this.name = name;
		this.number = number;
		this.price = price;
		this.content = content;
		id++ ;
	}

	
	
	
}
