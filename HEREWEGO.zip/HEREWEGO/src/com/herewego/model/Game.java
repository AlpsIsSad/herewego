package com.herewego.model;

public class Game {
	
	String gameName ;
	
	String gameDistrict ;
	
	public Game() {
		
		super();
		
	}

	public Game(String gameName, String gameDistrict) {
		
		super();
		
		this.gameName = gameName;
		
		this.gameDistrict = gameDistrict;
		
	}

	public String getGameName() {
		
		return gameName;
		
	}

	public void setGameName(String gameName) {
		
		this.gameName = gameName;
		
	}

	public String getGameDistrict() {
		
		return gameDistrict;
		
	}

	public void setGameDistrict(String gameDistrict) {
		
		this.gameDistrict = gameDistrict;
		
	}
	
	
	
	

}
