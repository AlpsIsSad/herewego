package com.herewego.model;

public class User {

	private String userName ;
	
	private String password ;
	
	private String nickName ;
	
	private String sex ;
	
	private int age ;
	
	private String constellation ;
	
	public User () {
		super() ;
	}
	
	public User(String userName, String password) {
		
		super();
		
		this.userName = userName;
		
		this.password = password;
		
	}
	
	public User(String userName, String nickName, String sex, int age, String constellation) {
		
		super();
		
		this.userName = userName;
		
		this.nickName = nickName;
		
		this.sex = sex;
		
		this.age = age;
		
		this.constellation = constellation;
		
	}
	
	

	public User(String userName, String password, String nickName, String sex, int age, String constellation) {
		
		super();
		
		this.userName = userName;
		
		this.password = password;
		
		this.nickName = nickName;
		
		this.sex = sex;
		
		this.age = age;
		
		this.constellation = constellation;
		
	}

	public String getUserName() {
		
		return userName;
		
	}

	public void setUserName(String userName) {
		
		this.userName = userName;
		
	}

	public String getPassword() {
		
		return password;
		
	}

	public void setPassword(String password) {
		
		this.password = password;
		
	}

	public String getNickName() {
		
		return nickName;
		
	}

	public void setNickName(String nickName) {
		
		this.nickName = nickName;
		
	}

	public String getSex() {
		
		return sex;
		
	}

	public void setSex(String sex) {
		
		this.sex = sex;
		
	}

	public int getAge() {
		
		return age;
		
	}

	public void setAge(int age) {
		
		this.age = age;
		
	}

	public String getConstellation() {
		
		return constellation;
		
	}

	public void setConstellation(String constellation) {
		
		this.constellation = constellation;
		
	} 
	
	


}
