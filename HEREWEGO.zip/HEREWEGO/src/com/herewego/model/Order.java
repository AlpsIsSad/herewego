package com.herewego.model;

public class Order {
	
	private int order_id ;

	private int good_id ;
	
	private String name ;
	
	private int number ;
	
	private String buy_id ;
	
	private String sell_id ;
	
	private float price ;
	
	private String time ;
	
	private String state ;

	public Order(int order_id, int good_id, String name, int number, String buy_id, String sell_id, float price,
			String time, String state) {
		super();
		this.order_id = order_id;
		this.good_id = good_id;
		this.name = name;
		this.number = number;
		this.buy_id = buy_id;
		this.sell_id = sell_id;
		this.price = price;
		this.time = time;
		this.state = state;
	}

	public Order() {
		// TODO Auto-generated constructor stub
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public int getGood_id() {
		return good_id;
	}

	public void setGood_id(int good_id) {
		this.good_id = good_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getBuy_id() {
		return buy_id;
	}

	public void setBuy_id(String buy_id) {
		this.buy_id = buy_id;
	}

	public String getSell_id() {
		return sell_id;
	}

	public void setSell_id(String sell_id) {
		this.sell_id = sell_id;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
	
	

}
