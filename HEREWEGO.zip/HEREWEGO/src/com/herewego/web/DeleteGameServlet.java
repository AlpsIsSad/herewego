package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.herewego.dao.UserDao;
import com.herewego.model.Game;
import com.herewego.model.User;
import com.herewego.util.DbUtil;

//删除游戏
public class DeleteGameServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	UserDao userDao = new UserDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String userName = req.getParameter("userName") ;
		
		String gameName = req.getParameter("game") ;
		
		String district = req.getParameter("district") ;
		
		Connection con = null ;
		
		try {
			
			Game game = new Game( gameName , district )  ;
			
			User user = new User(userName , "" ) ;
			
			con = dbUtil.getCon() ;
			
			boolean deleteGame = userDao.deleteGame(con, user, game) ;
			
			if ( deleteGame ) {
				
				req.setAttribute("deletegamesuccess", "删除游戏成功");
				
				req.getRequestDispatcher("addGame.jsp").forward(req, resp);
				
			}else {
				
				req.setAttribute("deletegamefalse", "你没有该游戏");
				
				req.getRequestDispatcher("addGame.jsp").forward(req, resp);
				
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
			}		
		}
	}

}
