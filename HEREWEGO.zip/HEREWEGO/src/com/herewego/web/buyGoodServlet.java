package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.herewego.dao.OrderDao;
import com.herewego.dao.UserDao;
import com.herewego.model.Good;
import com.herewego.model.User;
import com.herewego.util.DbUtil;


public class buyGoodServlet extends HttpServlet {

	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	UserDao userDao = new UserDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	//复写提交表单的方法
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String buyName = req.getParameter("userName") ;
	
		int good_id = Integer.parseInt(req.getParameter("goodId")) ;
		
		Connection con = null ;
		
		try {		
			
			Good good = new Good() ;
			
			OrderDao orderDao = new OrderDao() ;
			
			User user = new User() ;
			
			user.setUserName(buyName);
			
			con = dbUtil.getCon() ;
			
			good.setGood_id(good_id);
			
			boolean b = orderDao.buyOrder(con, good, user);
			
			if ( !b ) {
				
				req.setAttribute("buyfalse", "不存在此商品");
				
				req.getRequestDispatcher("goodInfo.jsp").forward(req, resp);
				
			}else {
				
				req.setAttribute("buysuccess", "购买成功" );
								
				req.getRequestDispatcher("goodInfo.jsp").forward(req, resp);
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		} finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
				
			}		
		}		
	}	
}
