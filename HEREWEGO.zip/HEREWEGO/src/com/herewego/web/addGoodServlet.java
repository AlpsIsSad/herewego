package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.herewego.dao.GoodDao;
import com.herewego.model.Good;
import com.herewego.model.User;
import com.herewego.util.DbUtil;

public class addGoodServlet extends HttpServlet {
	
private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	GoodDao goodDao = new GoodDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {	
				
		String userName = req.getParameter("userName") ;
		
		String name = req.getParameter("goodName") ;
		
		String newName = new String(name.getBytes("iso-8859-1"),"UTF-8");
		
		int number = Integer.parseInt(req.getParameter("number")); 
	
		float price = Float.parseFloat(req.getParameter("price")); 
		
		String content = req.getParameter("content") ;
		
		String newContent = new String(content.getBytes("iso-8859-1"),"UTF-8");
		
		Good good = new Good( newName, number , price , newContent ) ;
		
		User user = new User() ;
		
		user.setUserName(userName);
		
		Connection con = null ;
		
		try {
			
			con = dbUtil.getCon() ;
			
			boolean send = goodDao.addGood(con, good ,user );
			
			if ( send ) {
				
				req.setAttribute("addGoodSuccess", "上架成功");
				
				req.getRequestDispatcher("sell.jsp").forward(req, resp);
				
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
			}		
		}
	}

}


