package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.herewego.dao.UserDao;
import com.herewego.model.Game;
import com.herewego.model.User;
import com.herewego.util.DbUtil;

//注册
public class RegisterServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	UserDao userDao = new UserDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	//复写doPost方法
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		//从表单提交中获取用户基本信息
		String userName = req.getParameter("userName") ;
		
		String password = req.getParameter("password") ;
		
		String nickName = req.getParameter("nickName") ;
		
		String sex = req.getParameter("sex") ;
		
		int age = Integer.parseInt( req.getParameter("age") );
				
		String constellation = req.getParameter("constellation") ;
		
		String gameName = req.getParameter("game") ;
		
		String district = req.getParameter("district") ;
		
		Connection con = null ;
		
		try {
			
			//封装成两个对象
			User user = new User(userName, password, nickName, sex, age, constellation) ;
			
			Game game = new Game( gameName , district) ;
			
			con = dbUtil.getCon() ;
			
			boolean registerUser = userDao.register(con, user , game) ;
			
			//返回值为true表示该用户不存在，注册成功，赋值success为注册成功提醒用户
			if ( registerUser ) {
				
				req.setAttribute("success", "注册成功");
				
				req.getRequestDispatcher("register.jsp").forward(req, resp);
				
			}
			//返回值为false表示该用户存在，注册失败，赋值userFalse为用户名已经被占用提醒用户
			else {
				
				req.setAttribute("userfalse", "注册失败");
				
				req.getRequestDispatcher("register.jsp").forward(req, resp);
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
			}		
		}
	}
}
