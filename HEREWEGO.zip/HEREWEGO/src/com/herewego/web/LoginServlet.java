package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.herewego.dao.UserDao;
import com.herewego.model.User;
import com.herewego.util.DbUtil;

	// 登录
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	UserDao userDao = new UserDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	//复写提交表单的方法
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		//从提交中获取用户名，密码
		String userName = req.getParameter("userName") ;
		
		String password = req.getParameter("password") ;
		
		Connection con = null ;
		
		try {
			
			User user = new User( userName ,password ) ;
			
			con = dbUtil.getCon() ;
			
			User currentUser = userDao.login( con , user) ;
			
			//如果返回user为null，赋值error为用户名或密码错误提醒用户，返回登录界面
			if (currentUser == null ) {
				
				req.setAttribute("error", "用户名或密码错误");
				
				req.setAttribute("userName", userName);
				
				req.setAttribute("password", password);
				
				req.getRequestDispatcher("index.jsp").forward(req, resp);
				
			}else {
				
				//不为空则跳转页面至主页
				HttpSession session = req.getSession() ;
				
				session.setAttribute("currentUser", currentUser);
								
				resp.sendRedirect("main.jsp");
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		} finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
				
			}		
		}		
	}	
}
