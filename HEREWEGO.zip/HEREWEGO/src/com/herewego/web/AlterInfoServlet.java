package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.herewego.dao.UserDao;
import com.herewego.model.User;
import com.herewego.util.DbUtil;

//修改信息
public class AlterInfoServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	UserDao userDao = new UserDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String userName = req.getParameter("userName") ;
		
		String nickName = req.getParameter("nickName") ;
		
		String sex = req.getParameter("sex") ;
		
		int age = Integer.parseInt(req.getParameter("age")) ;
		
		String constellation = req.getParameter("constellation") ;		
		
		Connection con = null ;
		
		try {
			
			User user = new User(userName, nickName, sex, age, constellation) ;
			
			con = dbUtil.getCon() ;
			
			boolean alterUser = userDao.alterInfo(con, user) ;
			
			if ( alterUser ) {
				
				req.setAttribute("success", "修改信息成功");
				
				req.getRequestDispatcher("alterinformation.jsp").forward(req, resp);
				
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
			}		
		}
	}

}
