package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.herewego.dao.MessageDao;

import com.herewego.model.Message;

import com.herewego.util.DbUtil;

public class SendMessageServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	MessageDao messageDao = new MessageDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {	
				
		String userName = req.getParameter("userName") ;
		
		String toUserName = req.getParameter("touser") ;
		
		String message = req.getParameter("message") ;
		
		Message mes = new Message(userName, toUserName, message) ;
		
		Connection con = null ;
		
		try {
			
			con = dbUtil.getCon() ;
			
			boolean send = messageDao.sendMessage(con, mes) ;
			
			if ( send ) {
				
				req.setAttribute("sendsuccess", "发送信息失败");
				
				req.getRequestDispatcher("chat.jsp").forward(req, resp);
				
			}
			
			//登录获取商品列表获取推荐好友添加好友
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
			}		
		}
	}

}