package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.herewego.dao.OrderDao;
import com.herewego.dao.UserDao;

import com.herewego.model.Order;
import com.herewego.util.DbUtil;


public class showOrderServlet extends HttpServlet {

	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	UserDao userDao = new UserDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	//复写提交表单的方法
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		int order_id = Integer.parseInt(req.getParameter("orderId")) ;
		
		Connection con = null ;
		
		try {		
			
			if ( req.getParameter("orderId") == "" ) {
				
				req.setAttribute("idIsNotExit", "不存在此商品");
				
				req.getRequestDispatcher("order.jsp").forward(req, resp); }
			
			Order order = new Order() ;
			
			OrderDao orderDao = new OrderDao();

			con = dbUtil.getCon() ;
			
			order.setOrder_id(order_id);
			
			order = orderDao.getOrderInfo(con, order) ;
			
			if (order.getName() == null ) {
				
				req.setAttribute("idIsNotExit", "不存在此商品");
				
				req.getRequestDispatcher("order.jsp").forward(req, resp);
				
			}else {
				
				HttpSession session = req.getSession() ;
				
				session.setAttribute("order", order );
								
				resp.sendRedirect("orderInfo.jsp");
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		} finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
				
			}		
		}		
	}	
}
