package com.herewego.web;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.herewego.dao.GoodDao;
import com.herewego.dao.UserDao;
import com.herewego.model.Good;
import com.herewego.util.DbUtil;


public class showGoodServlet extends HttpServlet {

	private static final long serialVersionUID = 1L ;
	
	DbUtil dbUtil = new DbUtil() ;
	
	UserDao userDao = new UserDao() ;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		this.doPost(req, resp);
	}

	//复写提交表单的方法
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		int good_id = Integer.parseInt(req.getParameter("goodId")) ;
		
		Connection con = null ;
		
		try {		
			
			if ( req.getParameter("goodId") == "" ) {
				
				req.setAttribute("idIsNotExit", "不存在此商品");
				
				req.getRequestDispatcher("transaction.jsp").forward(req, resp); }
			
			Good good = new Good();
			
			GoodDao goodDao = new GoodDao();
			
			con = dbUtil.getCon() ;
			
			good.setGood_id(good_id);
			
			good = goodDao.getGoodInfo(con, good);
			
			if (good.getName() == null ) {
				
				req.setAttribute("idIsNotExit", "不存在此商品");
				
				req.getRequestDispatcher("transaction.jsp").forward(req, resp);
				
			}else {
				
				HttpSession session = req.getSession() ;
				
				session.setAttribute("good", good );
								
				resp.sendRedirect("goodInfo.jsp");
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		} finally {
			
			try {
				
				dbUtil.closeCon(con);
				
			} catch (Exception e) {

				e.printStackTrace();
				
			}		
		}		
	}	
}
